GOLDEN GANG legal pages

Files:
- index.html   (landing page)
- terms.html   (Terms of Service)
- privacy.html (Privacy Policy)

Suggested GitHub Pages setup:
1. Create a PUBLIC GitHub repository named golden-gang-legal.
2. Upload all three HTML files to the repository root (not inside another folder).
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish. Use the published site URL shown in Settings > Pages.
7. The policy URLs will be:
   https://YOUR-GITHUB-USERNAME.github.io/golden-gang-legal/terms.html
   https://YOUR-GITHUB-USERNAME.github.io/golden-gang-legal/privacy.html

Important:
- Replace YOUR-GITHUB-USERNAME with your real GitHub username.
- Check that both URLs open in a private/incognito browser window before adding them to Discord.
- These pages describe the current welcome-only code. Update them before adding features that collect, store, or process additional data.
- Do not upload .env, bot tokens, backup codes, or other secrets to this repository.
