GOLDEN GANG BOT - legal pages

Files:
- terms-of-service.html
- privacy-policy.html

IMPORTANT BEFORE PUBLISHING:
These are starter templates based on the current welcome-only bot code. Review them so they accurately describe how you operate the Bot. In particular, the Privacy Policy assumes the current version does not use a database, does not read ordinary server messages, and may show join-event usernames in the operator's console or hosting logs. Update the policy if you add moderation, giveaways, logs, analytics, or other features that process more information.

The contact wording refers to the support/contact channel in the GOLDEN GANG Discord server. Make sure members have a real way to contact the moderation team; create a support/contact channel if needed.

To publish with GitHub Pages:
1. Create a PUBLIC GitHub repository (for example: golden-gang-legal).
2. Upload both HTML files to the repository's root folder.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch; choose the main branch and / (root), then Save.
5. Wait for GitHub Pages to publish. The public links will be:
   https://YOUR-GITHUB-USERNAME.github.io/golden-gang-legal/terms-of-service.html
   https://YOUR-GITHUB-USERNAME.github.io/golden-gang-legal/privacy-policy.html
   Replace YOUR-GITHUB-USERNAME with your GitHub username.
6. Open each link in a private/incognito browser window to confirm it is publicly accessible.
7. Paste the Terms of Service URL and Privacy Policy URL into the corresponding fields in Discord Developer Portal > your app > General Information, then save.

GitHub Pages documentation:
https://docs.github.com/en/pages/getting-started-with-github-pages
